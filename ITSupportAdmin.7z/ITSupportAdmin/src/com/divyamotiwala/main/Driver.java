package com.divyamotiwala.main;

import java.util.Scanner;

import com.divyamotiwala.model.Employee;
import com.divyamotiwala.service.CredentialService;

public class Driver {

	
	public static void main(String[] args) {
		
		CredentialService credentialService = new CredentialService();
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter First Name : ");
		String firstName = sc.next();
		
		System.out.print("Please enter Last Name : ");
		String lastName = sc.next();
		
		Employee newEmployee = new Employee(firstName, lastName);
		int chosenOption;
		
		
		do {
			System.out.println("Please enter the department from the following : ");
			System.out.println("1. Technical \n2. Admin\n3. Human Resource\n4. Legal");
			chosenOption = sc.nextInt();
			
			switch(chosenOption)
			{
				case 1 : newEmployee.setDepartment("tech");
					break;
				case 2 : newEmployee.setDepartment("admin");
					break;
				case 3 : newEmployee.setDepartment("hr");
					break;
				case 4:	newEmployee.setDepartment("legal");
					break;
				default: System.out.println("Please enter valid department !");
					chosenOption = 0;
				
			}
		}while(chosenOption == 0);
		
		newEmployee.setPassword(credentialService.generatePassword());
		newEmployee.setEmail(credentialService.generateEmailAddress(newEmployee, "abc"));
		newEmployee.showCredentials();
		
		sc.close();
	}

}
