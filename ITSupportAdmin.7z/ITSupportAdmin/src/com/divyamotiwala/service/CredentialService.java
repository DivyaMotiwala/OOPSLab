package com.divyamotiwala.service;

import java.util.Random;

import com.divyamotiwala.model.Employee;

public class CredentialService {

	public String generatePassword()
	{
		String capitalChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallChars = capitalChars.toLowerCase();
		String numbers = "1234567890";
		String symbols = "!@#$%^&*_";
		String value = capitalChars + smallChars + numbers + symbols;
		
		int passwordLength = 8;
		char[] passwordArray = new char[passwordLength];
		
		Random randomNumberGenerator = new Random();
		int i =0;
		passwordArray[i++]  = capitalChars.charAt(randomNumberGenerator.nextInt(capitalChars.length() - 1));
		passwordArray[i++]  = smallChars.charAt(randomNumberGenerator.nextInt(smallChars.length() - 1));
		passwordArray[i++]  = numbers.charAt(randomNumberGenerator.nextInt(numbers.length() - 1));
		passwordArray[i++]  = symbols.charAt(randomNumberGenerator.nextInt(symbols.length() - 1));
		while(i < passwordLength)
		{
			passwordArray[i++]  = value.charAt(randomNumberGenerator.nextInt(value.length()));
		}
		
		return new String(passwordArray);
			  
	}
	public String generateEmailAddress(Employee newEmployee, String companyName)
	{
		StringBuffer email = new StringBuffer();
		email.append(newEmployee.getFirstName().toLowerCase());
		email.append(newEmployee.getLastName().toLowerCase());
		email.append("@");
		email.append(newEmployee.getDepartment());
		email.append(".");
		email.append(companyName);
		email.append(".com");
		return email.toString();
		
	}
	
	
	
}
